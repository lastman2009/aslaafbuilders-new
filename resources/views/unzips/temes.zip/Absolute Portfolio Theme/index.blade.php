<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Yellow Stylish Theme</title><link href="/unzips/Absolute%20Portfolio%20Theme/css/bootstrap.min.css" rel="stylesheet"><link href="/unzips/Absolute%20Portfolio%20Theme/css/font-awesome.css" rel="stylesheet"><link rel="stylesheet" href="/unzips/Absolute%20Portfolio%20Theme/css/owl.carousel.min.css"><link rel="stylesheet" type="text/css" href="/unzips/Absolute%20Portfolio%20Theme/css/jquery.mCustomScrollbar.css"><link href="/unzips/Absolute%20Portfolio%20Theme/css/theme.css" rel="stylesheet"><link href="/unzips/Absolute%20Portfolio%20Theme/css/custom.css" rel="stylesheet"></head><body>
 

        <header class="header" id="home"><div class="hdr-shade"></div>
            <div class="container-fluid menu-bar sticky">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 pr">
                            <div class="primary-menu">
                                <nav class="navbar navbar-inverse mb"><div class="container-fluid">
                                        <!-- Brand and toggle get grouped for better mobile display -->
                                        <div class="navbar-header">
                                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                                <span class="sr-only">Toggle navigation</span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                            </button>
                                            <a class="navbar-brand" href=""><img src="images/logo.png" alt=""></a>
                                        </div>

                                        <!-- Collect the nav links, forms, and other content for toggling -->
                                        <div class="collapse navbar-collapse no-padding" id="bs-example-navbar-collapse-1">
                                            <ul class="nav navbar-nav"><li class="active"><a href="#home">Home</a></li>
												<li><a href="#about">About Us</a></li>
												<li><a href="#work">Our Work</a></li>
												<li><a href="#ceo">CEO Message</a></li>
												<li><a href="#team">Our Team</a></li>
												<li><a href="#office">Offices</a></li>
												<li><a href="#contact">Contact Us</a></li>
                                            </ul></div><!-- /.navbar-collapse -->
                                    </div><!-- /.container-fluid -->


                                </nav></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 banner-text">
						<h1>Beautiful Dream House.</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .</p>
						<div class="banner-button">
							<a href="javascript:void(0);">
								<img src="images/drop-drow.png" alt=""></a>
						</div>
					</div>
                </div>
            </div>

        </header><div class="main">
			
			
			<section class="team-sect" id="team"><div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="team-title text-center">
								<h2>Our Property Agents</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden.</p>
							</div>
							<div class="owl-carousel">
								<div class="item">
									<figure><div class="img-container">
											<div class="img-block">
												<img class="img-responsive" src="images/team-1.jpg" alt="team-image"></div>
										</div>
										<figcaption><div class="team-heading">
												<h2>DAVID HASSI</h2>
											</div>
											<div class="team-detail">
												<p><span>CEO</span>:</p>
												<p>5 Years of service</p>
												<a href=""><i class="fa fa-facebook"></i></a>
												<a href=""><i class="fa fa-envelope"></i></a>
											</div>
										</figcaption></figure></div>
								<div class="item">
									<figure><div class="img-container">
											<div class="img-block">
												<img class="img-responsive" src="images/team-2.jpg" alt="team-image"></div>
										</div>
										<figcaption><div class="team-heading">
												<h2>DAVID HASSI</h2>
											</div>
											<div class="team-detail">
												<p><span>CEO</span>:</p>
												<p>5 Years of service</p>
												<a href=""><i class="fa fa-facebook"></i></a>
												<a href=""><i class="fa fa-envelope"></i></a>
											</div>
										</figcaption></figure></div>
								<div class="item">
									<figure><div class="img-container">
											<div class="img-block">
												<img class="img-responsive" src="images/team-3.jpg" alt="team-image"></div>
										</div>
										<figcaption><div class="team-heading">
												<h2>DAVID HASSI</h2>
											</div>
											<div class="team-detail">
												<p><span>CEO</span>:</p>
												<p>5 Years of service</p>
												<a href=""><i class="fa fa-facebook"></i></a>
												<a href=""><i class="fa fa-envelope"></i></a>
											</div>
										</figcaption></figure></div>
								<div class="item">
									<figure><div class="img-container">
											<div class="img-block">
												<img class="img-responsive" src="images/team-4.jpg" alt="team-image"></div>
										</div>
										<figcaption><div class="team-heading">
												<h2>DAVID HASSI</h2>
											</div>
											<div class="team-detail">
												<p><span>CEO</span>:</p>
												<p>5 Years of service</p>
												<a href=""><i class="fa fa-facebook"></i></a>
												<a href=""><i class="fa fa-envelope"></i></a>
											</div>
										</figcaption></figure></div>
								<div class="item">
									<figure><div class="img-container">
											<div class="img-block">
												<img class="img-responsive" src="images/team-1.jpg" alt="team-image"></div>
										</div>
										<figcaption><div class="team-heading">
												<h2>DAVID HASSI</h2>
											</div>
											<div class="team-detail">
												<p><span>CEO</span>:</p>
												<p>5 Years of service</p>
												<a href=""><i class="fa fa-facebook"></i></a>
												<a href=""><i class="fa fa-envelope"></i></a>
											</div>
										</figcaption></figure></div>
								
							</div>
						</div>
					</div>
				</div>
            </section><section class="ceo" id="ceo"><div class="container">
					<div class="row">
						<div class="col-lg-12 pr">
							<div class="col-lg-4 col-md-4 col-sm-4 ceo-img-section pl">
								<figure><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/ceo-img.jpg" alt="ceo-image"></div>
									</div>
								</figure></div>
							<div class="col-lg-8 col-md-8 col-sm-8 pl">
								<div class="ceo-section">
									<h2>CEO&rsquo;s Message</h2>
									<div class="mCustomScrollbar">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </section><section class="contact" id="contact"><div class="container">
					<div class="row">
						<div class="col-lg-12 pr">
							<div class="contact-title text-center">
								<h2>Contact us</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden.</p>
							</div>
							<div class="col-lg-5 col-md-5 col-sm-5 margin-topbottom ceo-img-section pl">
								<div class="slider-contact">
								  <div id="myCarousel" class="carousel slide" data-ride="carousel"> 
									<!-- Indicators -->
									<ol class="carousel-indicators"><li data-target="#myCarousel" data-slide-to="0" class="active">
									  <li data-target="#myCarousel" data-slide-to="1">
									  <li data-target="#myCarousel" data-slide-to="2">
									</ol><!-- Wrapper for slides --><div class="carousel-inner">
									  <div class="item active">
									  <h4>Lahore office</h4>
										<div class="office-addresses">
										  <ul><li><span><i class="fa fa-home"></i></span> DHA Phase 4, Block ff, house 43 lahore.</li>
											<li><span><i class="fa fa-mobile"></i></span> 0311-4065583</li>
											<li><span><i class="fa fa-envelope"></i></span> alit25402@gmail.com</li>
										  </ul></div>
									  </div>
									  <div class="item">
									  <h4>Islamabad office</h4>
										<div class="office-addresses">
										  <ul><li><span><i class="fa fa-home"></i></span> DHA Phase 4, Block ff, house 43 lahore.</li>
											<li><span><i class="fa fa-mobile"></i></span> 0311-4065583</li>
											<li><span><i class="fa fa-envelope"></i></span> alit25402@gmail.com</li>
										  </ul></div>
									  </div>
									  <div class="item">
									  <h4>Karachi office</h4>
										<div class="office-addresses">
										  <ul><li><span><i class="fa fa-home"></i></span> DHA Phase 4, Block ff, house 43 lahore.</li>
											<li><span><i class="fa fa-mobile"></i></span> 0311-4065583</li>
											<li><span><i class="fa fa-envelope"></i></span> alit25402@gmail.com</li>
										  </ul></div>
									  </div>
									</div>
								  </div>
								</div>
							</div>
							<div class="col-lg-7 col-md-7 col-sm-7 margin-topbottom pl">
								<div class="contact-form">
									<form role="form">
										<div class="form-group">
											<input type="text" class="form-control" id="name" name="name" placeholder="Name" required></div>
										<div class="form-group">
											<input type="text" class="form-control" id="email" name="email" placeholder="Email" required></div>
										<div class="form-group">
											<input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" required></div>
										<div class="form-group">
											<textarea class="form-control textarea-height" type="textarea" id="message" placeholder="Message" rows="7"></textarea></div>
										<button type="button" id="submit" name="submit" class="btn btn-primary btn-contact">Send</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
            </section><section class="about" id="about"><div class="container">
					<div class="row">
						<div class="col-lg-12 pr">
							<div class="col-lg-12 col-md-12 col-sm-12 pl">
								<div class="about-section">
									<h2>About Us</h2>
									<div class="mCustomScrollbar">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </section><section class="property-sect" id="work"><div class="container-fluid">
                <div class="container">
                    <div class="row">
                        <div class="work-title text-center">
								<h2>Our Work</h2>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proiden.</p>
							</div>
                        <div class="col-lg-12  pr">
                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-1.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                            <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>

                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-2.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                            <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>

                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-3.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                            <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>

                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-4.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                            <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>

                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-1.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                           <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>

                            <div class="col-md-4 col-sm-6 workportion pl">
                                <figure class="internal-sec"><div class="img-container">
										<div class="img-block">
											<img class="img-responsive" src="images/work-2.jpg" alt="work-image"></div>
									</div>
                                    <div class="overlay">
                                        <div class="text">
                                            <p>5 MARLA <span>HOUSE FOR</span> SALE</p>
                                            <p>PRICE:<span> Rs.25418</span></p>
                                            <button type="button" class="btn btn-default">VIEW DETAIL</button> 
                                        </div>
                                        <span class="top">for sale</span>
                                    </div>
                                </figure></div>
                        </div>
                    </div>
                </div>
            </div>
        </section></div>

		<footer id="office" class="footer"><div class="footer-top">
			<div class="container">
			  <div class="row">
				<div class="col-lg-12">
				  <div class="col-lg-4  col-md-4 office-addresses">
					<h1><img src="images/logo.png" alt=""></h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam luptatem.</p>
				  </div>
				  <div class="col-lg-4  col-md-4 col-xs-12 office-addresses follow">
					<h1>Follow on</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut .</p>
					<ul><li><a href="#"><i class="fa fa-facebook"></i></a></li>
					  <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					</ul></div>
				  <div class="col-lg-4  col-md-4 col-xs-12 office-addresses">
					<h1>Contact us</h1>
					<ul class="border-none"><li><span><i class="fa fa-home"></i></span> DHA Phase 4, Block ff, house 43 lahore.</li>
					  <li><span><i class="fa fa-map-marker"></i></span> 0311-4065583</li>
					  <li><span><i class="fa fa-envelope"></i></span> alit25402@gmail.com</li>
					</ul></div>
				</div>
			  </div>
			</div>
		  </div>
		  <div class="footer-btm">
			<div class="container">
			  <div class="row">
				<div class="col-lg-12">
				  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<p class="copyright">ALL REWARDS ARE CLEAR TECHNOLOGICALINC.</p>
				  </div>
				  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 backtotop"> <a href="javascript:" id="return-to-top" style=""><i class="fa fa-arrow-circle-up" aria-hidden="true"></i>Back to top</a> </div>
				</div>
			  </div>
			</div>
		  </div>
		</footer><script src="/unzips/Absolute%20Portfolio%20Theme/js/jquery-3.2.1.min.js"></script><script src="/unzips/Absolute%20Portfolio%20Theme/js/bootstrap.min.js"></script><script src="/unzips/Absolute%20Portfolio%20Theme/js/owl.carousel.js"></script><script type="text/javascript" src="/unzips/Absolute%20Portfolio%20Theme/js/jquery.mCustomScrollbar.concat.min.js"></script><script>
            $(document).ready(function () {

                $('.owl-carousel').owlCarousel({
                    loop: true,
                    dots: true,
                    margin: 10,
                    responsiveClass: true,
                    responsive: {
                        0: {
                            items: 1,
                            nav: false
                        },
                        600: {
                            items: 2,
                            nav: false
                        },
                        1000: {
                            items: 4,
                            dots: true,
                            nav: false,
                            loop: false
                        }
                    }
                });

				
				$(".banner-button a").click(function() {
					$('html,body').animate({
						scrollTop: $("#team").offset().top},
						'slow');
				});
				
				
                $('#return-to-top').click(function () {
                    $('body,html').animate({
                        scrollTop: 0
                    }, 500);
                });


            
				
				$(window).scroll(function(){
				  var sticky = $('.sticky'),
					  scroll = $(window).scrollTop();

				  if (scroll >= 100) sticky.addClass('fixed');
				  else sticky.removeClass('fixed');
				});
				
            });
        </script><script>
		
		$(document).ready(function(){
			$(".navbar-nav li a").on('click', function(event) {
				if (this.hash !== "") {
				  event.preventDefault();
				  var hash = this.hash;
				  $('html, body').animate({
					scrollTop: $(hash).offset().top
				  }, 900, function(){
				  });
				} 
			  });
		  
		    $(function(){
				$('.navbar-nav li a').click(function(){
					$('.navbar-nav').find('li.active').removeClass('active');
					$(this).parent().addClass('active');
					return false; //return false to aviod scroll top.
				});
			});
		})
		</script></body></html>
